Student-Management-System
=========================

This is an Android Implementation of a Student Monitoring system that teachers can use to keep track of their students. This was done as part of the DBMS-432 course. The app has been designed for Samsung Galaxy S3 or similiar xhdpi devices.
